/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Entity.BaseEntity;
import Util.TransactionUtil;
import java.util.List;
import java.util.function.Function;
import javax.persistence.EntityManager;

/**
 *
 * @author EKLOU Dodji
 * @param <T>
 * @param <Key>
 */
public class GenericDAO<T extends BaseEntity, Key extends Object>{
    protected Class<T> classEntity;
    
    public void add(T entity){
        TransactionUtil.executeUpdate(em ->{
            em.persist(entity);
        });
    }
    
    public T update(T entity){
        return TransactionUtil.executeQuery((EntityManager em) -> em.merge(entity));
    }
    
    public T find(Key id) {
        return TransactionUtil.executeQuery(em -> em.find(classEntity, id));
    }
    
    public void delete(T entity){
        TransactionUtil.executeUpdate(em -> {
            T em0 = em.merge(entity);
            em.remove(em0);
        });
    }
    
    public void delete(Key id){
        T entity =  this.find(id);
        if(entity != null){
            this.delete(entity);
        }
        
    }
    
    public List<T> toList() {
        return TransactionUtil.executeQuery((EntityManager em) -> {
            var query = em.createQuery("SELECT e FROM "
                    + classEntity.getSimpleName()
                    + " e",
                    classEntity);
            return query.getResultList();
        });
    }
    
}
