/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import DAO.GenericDAO;
import Entity.BaseEntity;
import java.util.List;

/**
 *
 * @author EKLOU Dodji
 * @param <T>
 * @param <Key>
 */
public class GenericService<T extends BaseEntity, Key extends Object>{
    protected GenericDAO<T,Key> dao;
    
    public void add(T entity){
        this.dao.add(entity);
    }
    
    public void update(T entity){
        this.dao.update(entity);
    }
    
    public T find(Key id){
        return this.dao.find(id);
    }
    
    public void delete(T entity){
        this.dao.delete(entity);
    }
    
    public void delete(Key id){
        this.dao.delete(id);
    }
    
    public List<T> toList(){
        return this.dao.toList();
    }
}
