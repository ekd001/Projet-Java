/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author EKLOU Dodji
 */
@Entity
@Table(name="author")
public class Author extends BaseEntity{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="id_author")
    private int id;
    
    @Column(name="name")
    private String name;
    
    @Column(name="nationality")
    private String Nationality;
    
    @OneToMany(mappedBy = "author",cascade=CascadeType.MERGE,fetch=FetchType.EAGER)
    private List<Title> titles;
    
    public Author(){}

    public Author(String name, String Nationality) {
        this.titles = new ArrayList<>();
        this.name = name;
        this.Nationality = Nationality;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getNationality() {
        return Nationality;
    }
    
    public List<Title> getTitles() {
        return titles;
    }


    public void setId(int id) {
        this.id = id;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public void setNationality(String Nationality) {
        this.Nationality = Nationality;
    }

    public void setTitles(Title title) {
        this.titles.add(title);
    }

    @Override
    public String toString() {
        return "Author{" + "id=" + id + ", name=" + name + ", Nationality=" + Nationality + ", titles=" + titles + '}';
    }
    
    
}
