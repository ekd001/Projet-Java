/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;

import java.io.Serializable;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

/**
 *
 * @author EKLOU Dodji
 */

@MappedSuperclass
public class BaseEntity implements Serializable {

    @Column(name = "date_creation")
    protected LocalDate dateCreation;
    
    @Column(name= "date_updated")
    protected LocalDate dateUpdate;

    public BaseEntity() {
        this.dateCreation = LocalDate.now();
    }
   
    public LocalDate getDateCreation() {
        return dateCreation;
    }

    public LocalDate getDateUpdate() {
        return dateUpdate;
    }

    public void setDateCreation(LocalDate dateCreation) {
        this.dateCreation = dateCreation;
    }

    public void setDateUpdate(LocalDate dateUpdate) {
        this.dateUpdate = dateUpdate;
    }

}

