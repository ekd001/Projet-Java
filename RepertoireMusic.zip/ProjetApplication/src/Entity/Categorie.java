/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

/**
 *
 * @author EKLOU Dodji
 */
@Entity
@Table(name="categorie")
public class Categorie extends BaseEntity{
    
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="id_categorie")
    private int id;
    
    @Column(name="label")
    private String label;
    
    @Column(name="description")
    private String description;
    
    @ManyToMany(mappedBy="categories", fetch=FetchType.EAGER, cascade={CascadeType.ALL})
    private List<Title> titles;
    
    public Categorie(){}

    public Categorie(String label, String description) {
        this.label = label;
        this.description = description;
        this.titles = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public String getLabel() {
        return label;
    }

    public String getDescription() {
        return description;
    }

    public List<Title> getTitles() {
        return titles;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setLabel(String label) {
        this.label = label;
    }
    
    public void setTitles(Title title) {
        this.titles.add(title);
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 19 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Categorie other = (Categorie) obj;
        return Objects.equals(this.id, other.id);
    }

    @Override
    public String toString() {
        return "Categorie{" + "id=" + id + ", label=" + label + ", description=" + description + ", titles=" + titles + '}';
    }
    
    
}
