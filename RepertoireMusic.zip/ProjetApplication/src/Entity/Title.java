/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 *
 * @author EKLOU Dodji
 */
@Entity
@Table(name="title")
public class Title extends BaseEntity{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="reference")
    private int reference;
    
    @Column(name="label")
    private String label;
    
    @Column(name="description")
    private String description;
    
    @Column(name="lyrics")
    private String lyrics;
    
    @Column(name="audio")
    private String audio;
    
    @ManyToOne(fetch=FetchType.EAGER)
    @JoinColumn(name="id_author")
    private Author author;
    
    @ManyToMany(fetch=FetchType.EAGER, cascade={CascadeType.ALL})
    @JoinTable(name="title_categorie", joinColumns = @JoinColumn(name="id_title"), 
            inverseJoinColumns = @JoinColumn(name="id_categorie"))
    private List<Categorie> categories = new ArrayList<>();
    
    
    public Title(){}

    /**
     *
     * @param label
     * @param description
     * @param lyrics
     * @param audio
     */
    public Title(String label, String description, String lyrics, String audio) {
        this.label = label;
        this.description = description;
        this.lyrics = lyrics;
        this.audio = audio;
    }

    public int getReference() {
        return reference;
    }

    public String getLabel() {
        return label;
    }

    public String getDescription() {
        return description;
    }

    public String getLyrics() {
        return lyrics;
    }

    public String getAudio() {
        return audio;
    }

    public Author getAuthor() {
        return author;
    }
    
    public List<Categorie> getCategories() {
        return categories;
    }

    public void setReference(int reference) {
        this.reference = reference;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setLyrics(String lyrics) {
        this.lyrics = lyrics;
    }

    public void setAudio(String audio) {
        this.audio = audio;
    }

    public void setCategories(Categorie categorie) {
        this.categories.add(categorie);
    }

    public void setAuthor(Author author) {
        this.author = author;
    }
    

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + Objects.hashCode(this.reference);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Title other = (Title) obj;
        return Objects.equals(this.reference, other.reference);
    }

    @Override
    public String toString() {
        return "Title{" + "reference=" + reference + ", label=" + label + ", description=" + description + ", lyrics=" + lyrics + ", audio=" + audio + ", author=" + author.getName()+'}';
    }
    
    
}
