/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package RepertoireMusic;

import Entity.Author;
import Entity.Categorie;
import Entity.Title;
import UI.CLI.MusicCli;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import static javax.persistence.Persistence.createEntityManagerFactory;

/**
 *
 * @author EKLOU Dodji
 */
public class RepertoireMusic {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        MusicCli repMusic = new MusicCli();
        repMusic.deleteMusic();
//        EntityManagerFactory emf = createEntityManagerFactory("jpaPU");
//        EntityManager em = emf.createEntityManager();
//        var title = new Title("Prover","Chanson de fate","Prover Prover","prover.mp3");
//        var categorie = new Categorie("Anime","les chansons d'anime");
//        var auteur = new Author("milet","Japonaise");
//        title.setCategories(categorie);
//        categorie.setTitles(title);
//        auteur.setTitles(title);
//        title.setAuthor(auteur);
//        try{
//            var transaction = em.getTransaction();
//            transaction.begin();
//            em.persist(title);
//            em.persist(categorie);
//            em.persist(auteur);
//            transaction.commit();
//        }catch(Exception e){
//            System.out.println(e);
//        }
//        
    }
    
}
