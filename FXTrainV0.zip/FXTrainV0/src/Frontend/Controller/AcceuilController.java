package Frontend.Controller;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */


import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.input.ContextMenuEvent;
import javafx.scene.layout.HBox;

/**
 * FXML Controller class
 *
 * @author EKLOU Dodji
 */
public class AcceuilController {
    
    @FXML
    private HBox btnTitre;
    
    

    @FXML
    public void initialize() {
        
    }    
    
     @FXML
    private void showContextMenu(ContextMenuEvent event) {
        // Afficher le menu contextuel à l'endroit du clic droit
        ContextMenu cm = new ContextMenu();
        MenuItem mn0 = new MenuItem("Ajouter un titre");
        MenuItem mn = new MenuItem("Actualiser");
        
        cm.getItems().add(mn0);
        cm.getItems().add(mn);
        cm.show(this.btnTitre, event.getScreenX(), event.getScreenY());
        
        mn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Actualiser");
                // Ajouter votre logique pour Option 1 ici
            }
        });
        
        mn0.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Ajouter un titre");
                // Ajouter votre logique pour Option 1 ici
            }
        });
    }

    @FXML
    private void actualiserAction() {
        // Action à exécuter lors du clic sur "Actualiser"
        System.out.println("Action Actualiser exécutée !");
    }
}
