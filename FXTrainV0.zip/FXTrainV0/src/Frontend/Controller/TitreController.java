/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Frontend.Controller;

import Backend.Entity.Title;
import Backend.Service.TitleService;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 * FXML Controller class
 *
 * @author EKLOU Dodji
 */
public class TitreController {

    /**
     * Initializes the controller class.
     */
    private TitleService titleService;
    private List<Title> titles;
    private int preNumber;
    
    @FXML
    private VBox titlesBox;
    
    @FXML
    private VBox gMetaData;
    
    //@FXML
    //private ScrollPane scrollPane;
    
    @FXML
    public void initialize() {
        //this.scrollPane.setStyle("-fx-background-color:black;");
        this.initializeTitleService();
        this.fetchTitle();
        this.myTitles();
        this.metaData();
    }
    
    public void initializeTitleService(){
        if(this.titleService == null){
            this.titleService = new TitleService();
        }
    }
    
    public void fetchTitle(){
        if(this.titles == null){
            this.titles = this.titleService.toList();
        }
    }
    
    public void myTitles(){
        titlesBox.getChildren().clear();
        try{
            var i = 1;
            for(Title t : titles){
                Label ref = new Label(Integer.toString(i));
                ref.getStyleClass().add("numero");
                
                Label label = new Label(t.getLabel());
                label.getStyleClass().add("titre");
                
                Label author = null;
                if(t.getAuthor() != null){
                    author = new Label(t.getAuthor().getName());
                    author.getStyleClass().add("auteur");
                }else{
                    author = new Label("inconnu");
                    author.getStyleClass().add("auteur");
                }
                
                VBox titleBox = new VBox(label,author);
                HBox titleHbox = new HBox(ref,titleBox);
                titleHbox.setPrefHeight(40);
                titleHbox.setSpacing(20);
                titleHbox.getStyleClass().add("titrebox");
                titlesBox.getChildren().add(titleHbox);
                i++;
            }
        }catch(Exception e){
            titlesBox.getChildren().add(new Label("Erreur de chargement ou Titres indisponible"));
            e.printStackTrace();
        }
        
    }
    
    public void metaData(){
        this.preNumber = this.titles.size();
        Label nbre = new Label(Integer.toString(preNumber)+" titres");
        nbre.getStyleClass().add("downLabel");
        this.gMetaData.getChildren().add(nbre);
    }
    
}
