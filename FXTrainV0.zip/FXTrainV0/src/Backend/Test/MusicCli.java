/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Backend.Test;

import Backend.Entity.Author;
import Backend.Entity.Categorie;
import Backend.Entity.Title;
import Backend.Service.AuthorService;
import Backend.Service.CategorieService;
import Backend.Service.TitleService;
import java.time.LocalDate;
import java.util.Scanner;

/**
 *
 * @author EKLOU Dodji
 */
public class MusicCli {
    private final TitleService service;
    private final AuthorService serviceAuthor;
    private final CategorieService servicecat;
    private final Scanner sc;
    
    public MusicCli(){
        this.service = new TitleService();
        this.serviceAuthor = new AuthorService();
        this.servicecat = new CategorieService();
        this.sc = new Scanner(System.in);
    }
    
    public void addNewMusicAndAuthor(){
        System.out.println("Entrer le libelle : ");
        var libelle = sc.next();
        System.out.println("Entrer la description : ");
        var desc = sc.next();
        System.out.println("Entrer le lyrics : ");
        var lyrics = sc.next();
        System.out.println("Entrer l'audio : ");
        var audio = sc.next();
        System.out.println("Entrer le nom de l'auteur : ");
        var name = sc.next();
        System.out.println("Enter la nationalité : ");
        var nationality = sc.next();
        Title title = new Title(libelle, desc, lyrics, audio);
        Author auteur = new Author(name,nationality);
        title.setAuthor(auteur);
        auteur.setTitles(title);
        this.serviceAuthor.add(auteur);
        this.service.add(title);
        
    }
    
    public void updateMusic(){
        System.out.println("Entrer la reference de musique : ");
        var id = sc.nextInt();
        
        if(this.service.find(id) != null){
            var title = this.service.find(id);
            System.out.println(title);
            System.out.println("Voulez vous modifier 1 pour oui et 0 pour non \n");
            var choix = sc.nextInt();
            switch(choix){
                case 1 : updateMusicName(title);break;
                case 0 : break;
                default : break;
            }
        }else{
            System.out.println("Non trouve");
        }
    }
    
    private void updateMusicName(Title t){
        System.out.println("Entrer le nouveau nom : ");
        Scanner sc1 = new Scanner(System.in);
        var label = sc1.nextLine();
        t.setLabel(label);
        t.setDateUpdate(LocalDate.now());
        this.service.update(t);
    }
    
    public void updateAuthor(){
        System.out.println("Entrer l'identifiant de l'auteur : ");
        var id = sc.nextInt();
        var sca = new Scanner(System.in);
        if(this.service.find(id) != null){
            var auteur = this.serviceAuthor.find(id);
            System.out.println("Entrer le nouveau nom : ");
            var name = sca.nextLine();
            auteur.setName(name);
            auteur.setDateUpdate(LocalDate.now());
            this.serviceAuthor.update(auteur);
        }
    }
    
    public void addCategorie(){
        System.out.println("Entrer le libelle : ");
        var libelle = sc.nextLine();
        System.out.println("Entrer la description");
        var desc = sc.nextLine();
        Categorie c = new Categorie(libelle,desc);
        this.servicecat.add(c);
    }
    
    public void addMusicAtCategorie(){
        System.out.println("Entrer la reference de la categorie : ");
        var id_categorie = sc.nextInt();
        System.out.println("Entrer la reference de la musique : ");
        var reference = sc.nextInt();
        var title = this.service.find(reference);
        var c = this.servicecat.find(id_categorie);
        title.setCategories(c);
        c.setTitles(title);
        this.service.update(title);
    }
    
    public void deleteMusic(){
        System.out.println("Entrer l'identifiant : ");
        var ref = sc.nextInt();
        this.service.delete(ref);
    }
    
    public void listerMesMusic(){
        var titles = this.service.toList();
        for(Title t : titles){
            System.out.println(t);
        }
    }
}
