/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Backend.Service;

import Backend.DAO.AuthorDAO;
import Backend.Entity.Author;

/**
 *
 * @author EKLOU Dodji
 */
public class AuthorService extends GenericService<Author, Integer>{
    public AuthorService(){
        this.dao = new AuthorDAO();
    }
}
