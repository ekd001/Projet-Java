/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Backend.Service;

import Backend.DAO.CategorieDAO;
import Backend.Entity.Categorie;

/**
 *
 * @author EKLOU Dodji
 */
public class CategorieService extends GenericService<Categorie, Integer>{
    public CategorieService(){
        this.dao = new CategorieDAO();
    }
}
