/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Backend.DAO;

import Backend.DAO.GenericDAO;
import Backend.Entity.Title;

/**
 *
 * @author EKLOU Dodji
 */
public class TitleDAO extends GenericDAO<Title,Integer>{
    public TitleDAO(){
        this.classEntity = Title.class;
    }
}
