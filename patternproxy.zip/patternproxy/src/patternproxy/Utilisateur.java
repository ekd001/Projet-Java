/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patternproxy;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author EKLOU Dodji
 */
public class Utilisateur implements ConnectionBD{
    private String nomUtilisateur;
    private String motDePasse;
    private ProxyConnection proxy;
    
    public Utilisateur(String nom, String motDePasse){
       this.nomUtilisateur = nom;
       this.motDePasse = motDePasse;
    }
    
    public Utilisateur(){
        
    }
    
    public void afficherUser(){
        String sql  = "SELECT * FROM Utilisateur WHERE nom_utilisateur=?";
        PreparedStatement state = this.preparedStatement(sql);
        try{
           state.setString(1, "tatsuya");
           ResultSet result = state.executeQuery();
           while(result.next()){
               System.out.printf("nom : %s et mot de passe : %s\n",result.getString(2),result.getString(3));
           }
           state.close();
           this.proxy.close();
        } catch (SQLException ex) {
            Logger.getLogger(Utilisateur.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @Override
    public PreparedStatement preparedStatement(String sql){
        if(this.proxy == null){
            this.proxy = new ProxyConnection();
        }
        return this.proxy.preparedStatement(sql);
    }
}
