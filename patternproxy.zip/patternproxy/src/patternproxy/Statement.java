/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patternproxy;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author EKLOU Dodji
 */
public class Statement implements ConnectionBD{
    private String url = "jdbc:postgresql://localhost:5432/epl";
    private String login = "postgres";
    private String password = "123456789";
    private Connection connection;
    public Statement(){
        this.connection();
    }
    
    @Override
    public PreparedStatement preparedStatement(String sql){
        try{
            return this.connection.prepareStatement(sql);
        }catch(SQLException ex){
            return null;
        }
    }
    
    
    private void connection(){
        try{
            this.connection = DriverManager.getConnection(url, login, password);
        }catch(SQLException e){
            e.printStackTrace();
        }
    }
    
    public void closeConnection(){
        
        try {
            this.connection.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
