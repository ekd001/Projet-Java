/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patternproxy;
import java.sql.*;
/**
 *
 * @author EKLOU Dodji
 */
public class ProxyConnection implements ConnectionBD{
    private Statement state;
    public ProxyConnection(){
        if(this.state == null){
            this.state = new Statement();
        }
    }
    
    @Override
    public PreparedStatement preparedStatement(String sql){
        return this.state.preparedStatement(sql);
    }
    
    public void close(){
        this.state.closeConnection();
    }
    
}
